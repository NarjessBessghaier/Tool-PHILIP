<?php
class Ver{

 public function __construct() { }
 
    public  function boire()
    {
      return rand(1000,10000);
    }

 public  function b()
    {
      return rand(5165276934,7875896281);
    }
public  function ele($f)
    {
       
      return rand(140,171);
    }
    public  function verg()
    {
       
      return rand(1,5)/5;
    }
}
?>