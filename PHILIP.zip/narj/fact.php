<?php
$fact1 = gmp_fact(242); // 5 * 4 * 3 * 2 * 1
$ff=strval($fact1);
echo substr($ff, 0, 4)

?>