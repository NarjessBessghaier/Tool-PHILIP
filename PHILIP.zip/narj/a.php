<?php
echo abs(-0.687074829932);
?>