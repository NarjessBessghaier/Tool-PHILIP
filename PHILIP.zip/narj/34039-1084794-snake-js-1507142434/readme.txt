Snake js--------
Url     : http://codes-sources.commentcamarche.net/source/34039-snake-jsAuteur  : eddyminetDate    : 03/08/2013
Licence :
=========

Ce document intitul� � Snake js � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Il s'agit d'un jeu du serpent, simple et efficace qui s'integre de mani&egrave;r
e discr&egrave;te dans une page web pour distraire les visiteurs par exemple ...

<br />Ce code utilise la classe graphique wz_jsgraphics.js v. 2.32 cr&eacute;&
eacute;e par Walter Zorn (Web: <a href='http://www.walterzorn.com' target='_blan
k'>http://www.walterzorn.com</a> ) pour l'affichage du jeu.
<br />A essayer abs
olument ! ;-)
<br /><a name='conclusion'></a><h2> Conclusion : </h2>
<br />Vu
 la simplicit&eacute; du code, il ne devrait pas rester trop de bug mais n'h&eac
ute;sitez pas &agrave; me les rapporter (eddy@interpc.fr).
<br />
<br />Si les
 touches directionnelles ne semblent pas r&eacute;pondre, cliquez une fois sur l
'&eacute;cran de jeu pour redonner le focus au document.
<br />
<br />Le jeu s
cintille desagr&eacute;ablement sous FireFox. Parfait sous IE (test&eacute; sous
 IE6 et FF 1.03).
<br />
<br />Merci &agrave; Walter Zorn pour sa classe de de
ssin.
